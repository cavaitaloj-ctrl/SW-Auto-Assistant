package com.swassistant

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null
    private val prefs by lazy { getSharedPreferences("swassistant", MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun text(s: String, size: Float = 15f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); setPadding(dp(8), dp(6), dp(8), dp(6))
    }
    private fun btn(s: String, click: () -> Unit) = Button(this).apply { text = s; setOnClickListener { click() } }

    private fun showPanel() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(24, 39, 57))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("SW ASSISTANT", 17f), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(btn("—") { showBubble() })
        header.addView(btn("×") { stopSelf() })
        root.addView(header)
        root.addView(text("Farmeo · TOA Normal · TOA Hard"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("INICIAR") { prefs.edit().putString("run_state", "En seguimiento").apply(); Toast.makeText(this@FloatingPanelService, "Seguimiento iniciado", Toast.LENGTH_SHORT).show() })
        row.addView(btn("PAUSAR") { prefs.edit().putString("run_state", "En pausa").apply(); Toast.makeText(this@FloatingPanelService, "Seguimiento pausado", Toast.LENGTH_SHORT).show() })
        row.addView(btn("DETENER") { prefs.edit().putString("run_state", "Detenido").apply(); Toast.makeText(this@FloatingPanelService, "Seguimiento detenido", Toast.LENGTH_SHORT).show() })
        root.addView(row)
        root.addView(text("Los controles gestionan el registro, no el combate."))
        val p = lp(dp(310), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(120)
        }
        params = p
        wm.addView(root, p)
        panel = root
        root.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x = ox + (sx-e.rawX).toInt(); p.y = oy + (e.rawY-sy).toInt(); wm.updateViewLayout(root,p); return true }
                }
                return false
            }
        })
    }

    private fun showBubble() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null
        val b = TextView(this).apply {
            text = "SW"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(35, 105, 145))
            setOnClickListener { showPanel() }
        }
        val p = lp(dp(58), dp(58)).apply { gravity = Gravity.TOP or Gravity.END; x=dp(12); y=dp(180) }
        wm.addView(b,p); bubble = b
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        if (kotlin.math.abs(e.rawX-sx)>dp(6) || kotlin.math.abs(e.rawY-sy)>dp(6)) moved=true
                        p.x=ox+(sx-e.rawX).toInt(); p.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) showPanel(); return true }
                }
                return false
            }
        })
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
