package com.swassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var body: LinearLayout
    private val prefs by lazy { getSharedPreferences("swassistant", MODE_PRIVATE) }
    private var currentSection = "Inicio"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun makeText(s: String, size: Float = 16f, color: Int = Color.WHITE): TextView =
        TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(dp(12), dp(10), dp(12), dp(10)) }

    private fun button(s: String, action: () -> Unit): Button =
        Button(this).apply { text = s; setOnClickListener { action() } }

    private fun base(title: String) {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(16))
            setBackgroundColor(Color.rgb(17, 24, 39))
        }
        outer.addView(makeText("SW AUTO ASSISTANT  ·  v0.4", 20f))
        outer.addView(makeText(title, 24f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Inicio", "Farmeo", "TOA Normal", "TOA Hard").forEach { name ->
            nav.addView(button(name) { showSection(name) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        outer.addView(nav)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        scroll.addView(body)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }

    private fun renderHome() {
        base("Panel principal")
        body.addView(makeText("Asistente para Summoners War", 19f))
        body.addView(makeText("Farmeo de runas, TOA Normal y TOA Hard. El asistente registra actividad y muestra tus notas; no juega ni pulsa botones del juego."))
        body.addView(button("Abrir panel flotante") { startFloating() })
        body.addView(button("Farmeo de runas") { showSection("Farmeo") })
        body.addView(button("TOA Normal") { showSection("TOA Normal") })
        body.addView(button("TOA Hard") { showSection("TOA Hard") })
        body.addView(makeText("Estado: ${prefs.getString("run_state", "Detenido")}"))
        body.addView(makeText("Runs registradas: ${prefs.getInt("runs", 0)}"))
    }

    private fun showSection(section: String) {
        currentSection = section
        when(section) {
            "Farmeo" -> renderFarm()
            "TOA Normal" -> renderToa(false)
            "TOA Hard" -> renderToa(true)
            else -> renderHome()
        }
    }

    private fun renderFarm() {
        base("Farmeo de runas")
        val dungeon = EditText(this).apply {
            hint = "Mazmorra (ej. Gigante / Dragón / Necro)"
            setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        body.addView(makeText("Objetivo de farmeo"))
        body.addView(dungeon)
        body.addView(button("Registrar run completada") {
            val n = prefs.getInt("runs", 0) + 1
            prefs.edit().putInt("runs", n).putString("last_dungeon", dungeon.text.toString()).apply()
            Toast.makeText(this, "Run registrada: $n", Toast.LENGTH_SHORT).show()
            showSection("Farmeo")
        })
        body.addView(makeText("Total de runs: ${prefs.getInt("runs", 0)}"))
        body.addView(makeText("Última mazmorra: ${prefs.getString("last_dungeon", "Sin registrar")}"))
        body.addView(makeText("Puedes usar el contador mientras juegas. El registro es manual."))
        body.addView(button("Reiniciar contador") {
            prefs.edit().putInt("runs", 0).apply()
            showSection("Farmeo")
        })
    }

    private fun renderToa(hard: Boolean) {
        val title = if (hard) "TOA Hard" else "TOA Normal"
        base(title)
        val floor = EditText(this).apply {
            hint = "Número de planta"; inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        val team = EditText(this).apply {
            hint = "Equipo utilizado / recomendado"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        val notes = EditText(this).apply {
            hint = "Notas: oleadas, jefe, estrategia..."
            minLines = 3; gravity = Gravity.TOP
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        body.addView(makeText("Registrar progreso · $title"))
        body.addView(floor); body.addView(team); body.addView(notes)
        body.addView(button("Guardar planta y notas") {
            val key = if (hard) "hard_notes" else "normal_notes"
            val entry = "Planta ${floor.text}: ${team.text} — ${notes.text}"
            val old = prefs.getString(key, "") ?: ""
            prefs.edit().putString(key, (old + "\n" + entry).trim()).apply()
            Toast.makeText(this, "Progreso guardado", Toast.LENGTH_SHORT).show()
            renderToa(hard)
        })
        body.addView(makeText("Historial guardado"))
        body.addView(makeText(prefs.getString(if (hard) "hard_notes" else "normal_notes", "Todavía no hay registros." ) ?: ""))
        body.addView(button("Borrar historial de esta modalidad") {
            prefs.edit().remove(if (hard) "hard_notes" else "normal_notes").apply()
            renderToa(hard)
        })
    }

    private fun startFloating() {
        if (!Settings.canDrawOverlays(this)) {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(i)
            Toast.makeText(this, "Activa 'Mostrar sobre otras apps' y vuelve a pulsar Abrir panel flotante.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingPanelService::class.java))
        Toast.makeText(this, "Panel flotante iniciado", Toast.LENGTH_SHORT).show()
    }
}
