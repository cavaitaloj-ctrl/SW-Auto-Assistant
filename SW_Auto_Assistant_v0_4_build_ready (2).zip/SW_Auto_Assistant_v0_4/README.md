# SW Auto Assistant v0.4

Proyecto fuente Android (Kotlin) para Android 8.0+.

## Incluye
- Panel principal con secciones Farmeo, TOA Normal y TOA Hard.
- Registro manual de runs y de notas por planta.
- Panel flotante Android con minimizar a burbuja, restaurar y arrastrar.
- Botones Iniciar/Pausar/Detener que cambian el estado del seguimiento.

## Limitaciones
- No pulsa controles de Summoners War, no inicia combates ni automatiza partidas.
- No recomienda todavía equipos automáticamente: los campos de equipos y notas son registros manuales.
- No se ha compilado ni probado en un dispositivo real; requiere Android Studio/Gradle y pruebas.
- El permiso "Mostrar sobre otras apps" debe concederse manualmente.
- El panel flotante puede no mostrarse encima de todas las pantallas del sistema o de ventanas protegidas.

## Compilar
Abrir la carpeta en Android Studio y ejecutar Build > Build Bundle(s) / APK(s) > Build APK(s).


## Compilar el APK

### Con Android Studio (ordenador)
1. Abre la carpeta del proyecto en Android Studio.
2. Espera a que Gradle sincronice y descargue dependencias.
3. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.

### Compilación en la nube con GitHub Actions
El proyecto incluye `.github/workflows/android.yml`. Sube el contenido del proyecto a un repositorio GitHub y ejecuta la acción **Build Android APK** desde la pestaña Actions. Al terminar, descarga el artefacto `SW-Auto-Assistant-debug-APK`.

La compilación de depuración sirve para pruebas; no es una versión firmada para publicar.
